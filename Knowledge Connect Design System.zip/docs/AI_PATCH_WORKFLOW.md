# Apply AI Patch — workflow usage

This repo ships a manual GitHub Actions workflow that lets you turn an AI-generated
unified diff into a real pull request **without touching your local machine**.

File: `.github/workflows/apply-ai-patch.yml`

## What it does

1. Checks out `base_branch` (default `claude-improvements`).
2. Saves your pasted patch to a file and verifies it applies cleanly.
3. Applies the patch.
4. Runs `pnpm install --frozen-lockfile`, `pnpm check`, and `pnpm build`.
5. Commits the changes on a new branch `new_branch_name` and opens a pull
   request back into `base_branch`.

If any step fails, the workflow stops and **no PR is opened** — so you never get
a misleading "green" PR for a broken patch.

## How to run it

1. Open the repo on GitHub.
2. Click the **Actions** tab.
3. In the left sidebar, click **Apply AI Patch**.
4. Click the **Run workflow** dropdown on the right.
5. Fill in the inputs:

   | Input             | What to put                                                                 |
   |-------------------|-----------------------------------------------------------------------------|
   | `patch_content`   | Paste the entire unified diff. See "Patch format" below.                    |
   | `base_branch`     | Branch the patch should apply on top of (default: `claude-improvements`).   |
   | `new_branch_name` | A new branch name, e.g. `ai/hex-board-polish` or `ai/win-condition`.        |
   | `pr_title`        | Short title for the PR, e.g. `Polish hex board spacing`.                    |
   | `pr_body`         | (Optional) Markdown description for the PR.                                 |

6. Click **Run workflow**.
7. Watch the run. When it finishes green, open the **Pull requests** tab — your
   new PR will be there, ready to review and merge.

## Patch format

The workflow expects the output of `git diff`, **not** `git format-patch`.

A valid patch starts like this:

```diff
diff --git a/client/src/components/HexBoard.tsx b/client/src/components/HexBoard.tsx
index abc1234..def5678 100644
--- a/client/src/components/HexBoard.tsx
+++ b/client/src/components/HexBoard.tsx
@@ -10,7 +10,7 @@
 ...
```

If the AI tool gives you a zip of changed files instead, you can produce a diff
locally with:

```bash
git checkout claude-improvements
git pull
# drop the AI-edited files into your working tree
git diff > patch.diff
# then paste the contents of patch.diff into the workflow input
```

## Common failures and fixes

| Error message                                              | Cause                                                                  | Fix                                                                                              |
|------------------------------------------------------------|------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------|
| `Patch does not apply cleanly to '<branch>'`               | Base branch moved on after the patch was generated.                    | Re-generate the diff against the latest commit on `base_branch`.                                  |
| `Patch applied but produced zero file changes`             | The diff was empty or matched the working tree exactly.                | Check that you pasted the full diff including the `diff --git` headers.                          |
| `pnpm install --frozen-lockfile` fails with lockfile error | Patch touches `package.json` without updating `pnpm-lock.yaml`.        | Run `pnpm install` locally, include the regenerated `pnpm-lock.yaml` in the diff, and re-paste.  |
| `pnpm check` or `pnpm build` fails                          | Patch introduces a TypeScript or build error.                          | Ask the AI to fix and re-deliver. The workflow will refuse to open a PR with a broken build.     |

## Security model

The workflow is intentionally locked down:

- **Manual trigger only.** It uses `workflow_dispatch`. No `pull_request`,
  `push`, or `issue_comment` triggers, so a fork or anonymous user can't run it.
- **Repo-write permission lives with the user who clicks "Run workflow"** —
  GitHub already gates that behind your repo collaborator settings. Keep
  Actions write access scoped to maintainers under
  *Settings → Actions → General → Workflow permissions*.
- **No external secrets are referenced.** The default `GITHUB_TOKEN` is the
  only credential used, and it's scoped to `contents: write` and
  `pull-requests: write` for this workflow only.
- **Concurrency guard.** Two runs targeting the same `new_branch_name` will not
  overlap.
- **Hard guard inside the job:** `if: github.event_name == 'workflow_dispatch'`
  refuses to run if the workflow is ever wired to another trigger by mistake.

## Required GitHub repo settings

Before the first run, confirm these in **Settings → Actions → General**:

1. **Actions permissions** → *Allow all actions and reusable workflows* (or
   *Allow select actions* with `actions/checkout`, `actions/setup-node`,
   `pnpm/action-setup`, and `peter-evans/create-pull-request` allow-listed).
2. **Workflow permissions** → *Read and write permissions*.
3. **Allow GitHub Actions to create and approve pull requests** → ✅ enabled.
   Without this, `peter-evans/create-pull-request` will fail at the PR step.

That's it. After those three boxes are checked, the workflow is ready to use.

## What this workflow does *not* do

- It does not auto-merge PRs. A human still reviews and merges.
- It does not run tests beyond `pnpm check` and `pnpm build`. Add a `test` step
  if/when the project gets a test suite.
- It does not modify production secrets, deployment, or Firebase config.
- It does not change the app's Arabic-only RTL behavior, theming, or routing —
  it's pure plumbing for getting AI patches into PRs safely.
